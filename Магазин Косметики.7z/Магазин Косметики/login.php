<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = htmlspecialchars($_POST['email']);
    $password = $_POST['password'];

    $file = 'users.json';
    if (!file_exists($file)) {
        echo "Немає зареєстрованих користувачів.";
        exit;
    }

    $users = json_decode(file_get_contents($file), true);

    // Перевірка логіну
    foreach ($users as $user) {
        if ($user['email'] == $email && password_verify($password, $user['password'])) {
            echo "Вхід успішний! Вітаємо, " . $user['username'];
            exit;
        }
    }
    echo "Неправильний email або пароль.";
}
?>
