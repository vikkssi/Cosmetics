<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = htmlspecialchars($_POST['username']);
    $email = htmlspecialchars($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Зберігання даних у JSON-файлі
    $file = 'users.json';
    $users = file_exists($file) ? json_decode(file_get_contents($file), true) : [];

    // Перевірка чи email вже існує
    foreach ($users as $user) {
        if ($user['email'] == $email) {
            echo "Користувач з такою електронною поштою вже існує.";
            exit;
        }
    }

    // Додаємо нового користувача
    $users[] = ['username' => $username, 'email' => $email, 'password' => $password];
    file_put_contents($file, json_encode($users, JSON_PRETTY_PRINT));
    echo "Реєстрація успішна!";
}
?>
