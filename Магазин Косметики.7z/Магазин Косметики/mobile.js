const menu = document.querySelector('#mobile-menu');
const menuLinks = document.querySelector('.navbar__menu');

menu.addEventListener('click', function() {
    menu.classList.toggle('is-active');
    menuLinks.classList.toggle('active');
});

// Реєстрація
document.getElementById('registrationForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Запобігає перезавантаженню сторінки

    // Отримання значень із форми
    const username = document.getElementById('username').value.trim();
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirm-password').value;

    // Перевірка паролів
    if (password !== confirmPassword) {
        alert('Паролі не співпадають. Спробуйте ще раз.');
        return;
    }

    // Збереження даних (приклад - виведення в консоль)
    console.log('Ім\'я користувача:', username);
    console.log('Електронна пошта:', email);
    console.log('Пароль:', password);

    // Повідомлення про успіх
    alert('Реєстрація пройшла успішно!');
});
