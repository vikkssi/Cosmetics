const menu = document.querySelector('#mobile-menu');
const menuLinks = document.querySelector('.navbar__menu');

menu.addEventListener('click', function() {
    menu.classList.toggle('is-active');
    menuLinks.classList.toggle('active');
});

let currentIndex = 0;

function changeSlide(step) {
    const slider = document.getElementById('slider');
    slider.style.transition = "opacity 0.5s ease-in-out"; // Плавний перехід
    slider.style.opacity = 0; // Зміщуємо зображення на початковий етап

    setTimeout(() => {
        currentIndex += step;
        if (currentIndex >= images.length) currentIndex = 0;
        if (currentIndex < 0) currentIndex = images.length - 1;
        slider.src = images[currentIndex]; // Міняємо зображення
        slider.style.opacity = 1; // Плавно відновлюємо видимість
    }, 500); // Чекаємо завершення анімації перед зміною зображення
}




/* REGISTER */

document.getElementById('registrationForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Запобігає перезавантаженню сторінки

    // Отримання значень із форми
    const username = document.getElementById('username').value.trim();
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirm-password').value;

    // Перевірка паролів
    if (password !== confirmPassword) {
        alert('Паролі не співпадають. Спробуйте ще раз.');
        return;
    }

    // Збереження даних (приклад - виведення в консоль)
    console.log('Ім\'я користувача:', username);
    console.log('Електронна пошта:', email);
    console.log('Пароль:', password);

    // Повідомлення про успіх
    alert('Реєстрація пройшла успішно!');
    // Тут можна додати запит на сервер для збереження даних
});

function searchProduct() {
    let input = document.getElementById('search').value.toLowerCase(); // Отримуємо значення пошуку
    let products = document.querySelectorAll('.product__item'); // Вибираємо всі елементи товарів
    let allProductsHeading = document.getElementById('all-products-heading');
    let lipsticksHeading = document.getElementById('lipsticks-heading');
    let perfumesHeading = document.getElementById('perfumes-heading');
    
    let hasResults = false; // Перевірка на наявність результатів пошуку

    products.forEach(function(product) {
        let title = product.querySelector('h3').textContent.toLowerCase(); // Отримуємо назву товару
        if (title.includes(input)) {
            product.style.display = ''; // Покажемо товар, якщо його назва містить пошуковий запит
            hasResults = true;
        } else {
            product.style.display = 'none'; // Сховаємо товар, якщо його назва не містить запит
        }
    });

    // Сховати або показати заголовки залежно від наявності результатів
    if (!hasResults) {
        allProductsHeading.style.display = 'none';
        lipsticksHeading.style.display = 'none';
        perfumesHeading.style.display = 'none';
    } else {
        allProductsHeading.style.display = '';
        lipsticksHeading.style.display = '';
        perfumesHeading.style.display = '';
    }
}

let cartCount = 0;  // Лічильник товарів у кошику

// Функція для додавання товару в кошик
function addToCart(productName, price) {
    cart.push({ productName, price });  // Додаємо товар до масиву кошика
    cartCount++;  // Збільшуємо лічильник товарів
    document.getElementById('cart-count').textContent = cartCount;  // Оновлюємо відображення кількості товарів
    alert(`Товар ${productName} додано до кошика за ${price} грн!`);  // Виводимо повідомлення
}

// Додаємо слухачі подій для кнопок "Додати в кошик"
document.querySelectorAll('.add-to-cart').forEach(button => {
    button.addEventListener('click', function() {
        const product = this.closest('.product');
        if (product) {
            const productName = product.querySelector('h3') ? product.querySelector('h3').textContent : '';
            const price = product.dataset.price || 0;
            if (productName && price) {
                addToCart(productName, price);
            } else {
                alert("Помилка: відсутні дані для товару!");
            }
        } else {
            alert("Помилка: не знайдено товар!");
        }
    });
});

let cart = [];  // Масив для зберігання товарів у кошику

// Функція для додавання товару в кошик
function addToCart(productName, price) {
    cart.push({ productName, price });  // Додаємо товар до масиву кошика
    cartCount++;  // Збільшуємо лічильник товарів
    document.getElementById('cart-count').textContent = cartCount;  // Оновлюємо відображення кількості товарів
    alert(`Товар ${productName} додано до кошика за ${price} грн!`);  // Виводимо повідомлення
}

// Функція для відображення інформації про кошик
function displayCart() {
    const cartContainer = document.getElementById('cart-container');
    cartContainer.innerHTML = '';  // Очищаємо попередній вміст

    let total = 0;  // Змінна для обчислення загальної вартості
    cart.forEach(item => {
        const productElement = document.createElement('div');
        productElement.classList.add('cart-item');
        productElement.textContent = `${item.productName} - ${item.price} грн`;
        cartContainer.appendChild(productElement);
        total += item.price;  // Додаємо ціну товару до загальної вартості
    });

    const totalElement = document.createElement('div');
    totalElement.classList.add('cart-total');
    totalElement.textContent = `Загальна вартість: ${total} грн`;
    cartContainer.appendChild(totalElement);

    // Оновлюємо відображення кількості товарів у кошику
    document.getElementById('cart-count').textContent = cartCount;
}

// Функція для оформлення замовлення
function checkout() {
    if (cart.length === 0) {
        alert('Ваш кошик порожній! Додайте товари перед оформленням замовлення.');
        return;
    }

    // Виводимо список товарів та загальну суму в окреме вікно або блок
    displayCart();

    // Можна додати логіку для надсилання замовлення на сервер або додаткових перевірок
    alert('Замовлення оформлено!');
}

// Додаємо слухачі подій для кнопок "Додати в кошик"
document.querySelectorAll('.add-to-cart').forEach(button => {
    button.addEventListener('click', function() {
        const product = this.closest('.product');
        if (product) {
            const productName = product.querySelector('h3') ? product.querySelector('h3').textContent : '';
            const price = parseInt(product.dataset.price) || 0;
            if (productName && price) {
                addToCart(productName, price);
            } else {
                alert("Помилка: відсутні дані для товару!");
            }
        } else {
            alert("Помилка: не знайдено товар!");
        }
    });
});

// Додаємо слухач для оформлення замовлення
document.getElementById('checkout-button').addEventListener('click', checkout);


function filterByPrice() {
    const minPrice = parseInt(document.getElementById('minPrice').value) || 0;
    const maxPrice = parseInt(document.getElementById('maxPrice').value) || Infinity;

    const products = document.querySelectorAll('.product__item');
    products.forEach(product => {
        const productPrice = parseInt(product.getAttribute('data-price'));
        if (productPrice >= minPrice && productPrice <= maxPrice) {
            product.style.display = 'block'; // Показати товар
        } else {
            product.style.display = 'none'; // Приховати товар
        }
    });
}

function filterByPrice() {
    const minPrice = parseFloat(document.getElementById('minPrice').value) || 0;
    const maxPrice = parseFloat(document.getElementById('maxPrice').value) || Infinity;

    const products = document.querySelectorAll('.product__item');
    products.forEach(product => {
        const productPrice = parseFloat(product.getAttribute('data-price')) || 0;
        if (productPrice >= minPrice && productPrice <= maxPrice) {
            product.style.display = 'block';
        } else {
            product.style.display = 'none';
        }
    });
}

